
const list = document.getElementById('adminProductList');
let products = JSON.parse(localStorage.getItem('products') || '[]');

function render(){
  list.innerHTML = '';
  products.forEach((p,i)=>{
    const div = document.createElement('div');
    div.innerHTML = `<strong>${p.name}</strong> - ${p.price}
    <button onclick="removeProduct(${i})">Remove</button>`;
    list.appendChild(div);
  });
}
function removeProduct(i){
  products.splice(i,1);
  localStorage.setItem('products', JSON.stringify(products));
  render();
}
render();
