
function saveProducts(products){
  products.forEach(p=>{
    db.collection("products").add(p);
  });
  alert("Products saved globally (all devices)");
}
