
document.addEventListener("DOMContentLoaded", function(){

  const container = document.getElementById("products");
  if(!container) return;

  db.collection("products").onSnapshot(snapshot=>{
    container.innerHTML = "";
    snapshot.forEach(doc=>{
      const p = doc.data();
      container.innerHTML += `
        <div class="product">
          <img src="${p.image}">
          <h3>${p.name}</h3>
          <p>Rs ${p.price}</p>
          <button onclick='addToCart(${JSON.stringify(p)})'>Add to Cart</button>
        </div>
      `;
    });
  });

});

function addToCart(p){
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  cart.push(p);
  localStorage.setItem("cart", JSON.stringify(cart));
  alert("Fatima Collection – Cart me add ho gaya");
}
