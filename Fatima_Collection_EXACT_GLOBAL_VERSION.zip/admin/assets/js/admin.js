
function addProduct(){
  let products = JSON.parse(localStorage.getItem("products")) || [];

  const product = {
    id: Date.now(),
    name: document.getElementById("name").value,
    price: document.getElementById("price").value,
    image: document.getElementById("image").value,
    page: document.getElementById("pageSelect").value
  };

  products.push(product);
  localStorage.setItem("products", JSON.stringify(products));
  alert("Product Added to " + product.page + " page");
}
