
let imageData = "";

document.getElementById("image").addEventListener("change", function(){
  const file = this.files[0];
  const reader = new FileReader();
  reader.onload = function(){
    imageData = reader.result;
    document.getElementById("preview").src = imageData;
  }
  reader.readAsDataURL(file);
});

function saveProduct(page){
  let products = JSON.parse(localStorage.getItem("products")) || [];
  const product = {
    id: Date.now(),
    name: document.getElementById("name").value,
    price: document.getElementById("price").value,
    image: imageData,
    page: page
  };
  products.push(product);
  localStorage.setItem("products", JSON.stringify(products));
  alert("Product added to " + page.toUpperCase());
}

function addHome(){ saveProduct("home"); }
function addShop(){ saveProduct("shop"); }
