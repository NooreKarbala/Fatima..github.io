document.addEventListener("DOMContentLoaded", () => {

  var cart = JSON.parse(localStorage.getItem("cart")) || [];
  var container = document.getElementById("cartItems");

  if (!cart.length) {
    container.innerHTML = "<p>Your cart is empty.</p>";
    return;
  }

  var total = 0;

  cart.forEach(item => {
    container.innerHTML += `
      <p>
        <span>${item.name}</span>
        <span>Rs ${item.price}</span>
      </p>
    `;
    total += Number(item.price);
  });

  container.innerHTML += `
    <hr>
    <p><strong>Total:</strong> Rs ${total}</p>
  `;
});