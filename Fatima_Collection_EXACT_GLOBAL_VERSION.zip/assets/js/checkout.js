
function checkoutWhatsApp(){
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  if(cart.length === 0){
    alert("Your cart is empty");
    return;
  }

  let message = "Hello, I want to place an order:\n";
  let total = 0;

  cart.forEach((item, i) => {
    message += (i+1) + ". " + item.name + " - CAD $" + item.price + "\n";
    total += Number(item.price);
  });

  message += "\nTotal: CAD $" + total;

  let url = "https://wa.me/14035507274?text=" + encodeURIComponent(message);
  window.location.href = url;
}
