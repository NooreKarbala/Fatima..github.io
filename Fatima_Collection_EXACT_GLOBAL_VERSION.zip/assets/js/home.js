
document.addEventListener("DOMContentLoaded",()=>{
  let products = JSON.parse(localStorage.getItem("products")) || [];
  let box = document.getElementById("home-products");
  if(!box) return;
  products.filter(p=>p.page==="home").forEach(p=>{
    box.innerHTML += `<div><img src="${p.image}" width="100"><h4>${p.name}</h4><p>${p.price}</p></div>`;
  });
});
