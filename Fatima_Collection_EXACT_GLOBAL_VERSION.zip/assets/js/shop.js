
const STORAGE_KEY = "fatima_products";
const products = JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
const container = document.getElementById("shopProducts");

container.innerHTML = "";

products.forEach(p=>{
  const div = document.createElement("div");
  div.className = "product";
  div.innerHTML = `
    <img src="${p.image}" style="width:180px;height:auto;border-radius:10px;">
    <h3>${p.name}</h3>
    <p>${p.price}</p>
  `;
  container.appendChild(div);
});
