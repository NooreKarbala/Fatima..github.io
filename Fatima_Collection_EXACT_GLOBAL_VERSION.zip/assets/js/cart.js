
document.addEventListener("DOMContentLoaded",()=>{
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  let box = document.getElementById("cart-items");
  let total = 0;
  box.innerHTML = "";

  cart.forEach((p,index)=>{
    total += Number(p.price);
    box.innerHTML += `
      <div class="cart-item">
        <img src="${p.image}">
        <div>
          <h4>${p.name}</h4>
          <p>$${p.price}</p>
          <button onclick="removeItem(${index})">Remove</button>
        </div>
      </div>`;
  });

  document.getElementById("total").innerText = "Total: $" + total;
});

function removeItem(i){
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  cart.splice(i,1);
  localStorage.setItem("cart",JSON.stringify(cart));
  location.reload();
}
